@extends('layouts.home')

@section('content')

	
	<br><br><br><br>
	
	<div class="container">
		<div class="page-header">
			<h1 class="text-info" align="center"> General Meal System </h1>
		</div>
		
	</div>



	<footer class="text-center" style="font-size: 20px"><i class="fa fa-heart"></i> Powered By <a target="_blank" href="https://www.MasiurSiddiki.com">www.MasiurSiddiki.com</a> <br>  ---!--- <br> Copyright ©2016 - {{ Date('Y') }} <a target="_blank" href="https://www.MasiurSiddiki.com/">Masiur</a> & <a target="_blank" href="https://www.linkedin.com/in/md-nayeem-iqubal/">Joy</a> </footer>

	
@stop
