<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>A Flat User has been Created</h2>

		<div>
			<p>Username: {{ $flat_short_name }}</p>
			<p>Email: {{ $email }}</p>
			<p>Password: {{ $password }}</p>
			<p>Mobile: {{ $flat_mobile_number }}</p>

        

		</div>
		<p>You can login from http://code.com.bd/meal/login</p>
	</body>
</html>
