<?php

return [
	'names' =>[
		'siteName' => 'General Meal System'
	],
	'roles' =>[
		'admin' => 'admin'
	]
];